package basic.crud

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
